<?php if (!defined('ABSPATH')) { exit; } ?>
<footer><div class="footer-main wrap"><div class="footer-brand"><?php megas_brand(); ?><a class="small-link" href="<?php echo esc_url(megas_contact_url()); ?>"><?php echo esc_html(megas_t('Μιλήστε μαζί μας','Get in touch')); ?> <?php megas_arrow(); ?></a>
<?php $social_links=array('Facebook'=>get_theme_mod('megas_facebook_url',''),'Instagram'=>get_theme_mod('megas_instagram_url','')); if(array_filter($social_links)): ?>
<nav class="footer-socials" aria-label="<?php echo esc_attr(megas_t('Κοινωνικά δίκτυα','Social media')); ?>
<?php foreach($social_links as $network=>$social_url): if(!$social_url){continue;} ?><a href="<?php echo esc_url($social_url); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($network); ?> <span aria-hidden="true">↗</span></a><?php endforeach; ?>
</nav><?php endif; ?></div>
<div><h3><?php echo esc_html(megas_t('Η εταιρεία','Company')); ?></h3><?php if(has_nav_menu('footer_company')):wp_nav_menu(array('theme_location'=>'footer_company','container'=>false,'depth'=>1));else: ?>
<a href="<?php echo esc_url(megas_world_url('about')); ?>"><?php echo esc_html(megas_t('Σχετικά με εμάς','About us')); ?></a><a href="<?php echo esc_url(megas_products_url()); ?>"><?php echo esc_html(megas_t('Τα προϊόντα μας','Our products')); ?></a><?php endif; ?></div>
<div><h3><?php echo esc_html(megas_t('Επαγγελματίες','Professionals')); ?></h3><?php if(has_nav_menu('footer_business')):wp_nav_menu(array('theme_location'=>'footer_business','container'=>false,'depth'=>1));else: ?><a href="<?php echo esc_url(megas_contact_url()); ?>"><?php echo esc_html(megas_text('professional_button')); ?></a><?php endif; ?></div>
<div><h3><?php echo esc_html(megas_t('Χρήσιμα','Useful links')); ?></h3><a href="<?php echo esc_url(megas_stockists_url()); ?>"><?php echo esc_html(megas_t('Πού θα τον βρεις','Where to find it')); ?></a><?php if(has_nav_menu('footer_help')):wp_nav_menu(array('theme_location'=>'footer_help','container'=>false,'depth'=>1));else: ?><a href="<?php echo esc_url(megas_faq_url()); ?>">FAQ</a><?php endif; ?>
<?php if(get_privacy_policy_url()): ?><a href="<?php echo esc_url(get_privacy_policy_url()); ?>"><?php echo esc_html(megas_t('Πολιτική απορρήτου','Privacy policy')); ?></a><?php endif; ?>
<?php if(get_theme_mod('megas_terms_url','')): ?><a href="<?php echo esc_url(get_theme_mod('megas_terms_url')); ?>"><?php echo esc_html(megas_t('Όροι χρήσης','Terms of use')); ?></a><?php endif; ?></div>
<div class="footer-contact"><h3><?php echo esc_html(megas_t('Επικοινωνία','Contact')); ?></h3>
<?php $phone=megas_contact_value('phone');if($phone): ?><a href="tel:<?php echo esc_attr(preg_replace('/[^+0-9]/','',$phone)); ?>"><?php echo esc_html($phone); ?></a><?php endif; ?>
<?php $email=megas_contact_value('email');if(is_email($email)): ?><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a><?php endif; ?>
<?php $address=megas_contact_value('address');if($address): ?><span><?php echo esc_html($address); ?></span><?php endif; ?>
<a href="<?php echo esc_url(megas_contact_url()); ?>"><?php echo esc_html(megas_t('Φόρμα επικοινωνίας','Contact form')); ?> <?php megas_arrow(); ?></a></div></div><div class="footer-bottom wrap"><span>© <?php echo esc_html(wp_date('Y')); ?> Μέγας Ελληνικός Καφές</span><span><?php echo esc_html(megas_t('Με μεράκι, σε κάθε φλιτζάνι.','Made with care, in every cup.')); ?></span><a href="#top"><?php echo esc_html(megas_t('Πίσω στην αρχή','Back to top')); ?> ↑</a></div></footer>
<?php wp_footer(); ?></body></html>
