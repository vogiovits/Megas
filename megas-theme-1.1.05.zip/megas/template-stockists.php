<?php
/* Template Name: Μέγας — Πού θα τον βρεις */
if (!defined('ABSPATH')) { exit; }
$stores=megas_stockists();
get_header();
?>
<main id="main-content" class="stockists-page">
<section class="page-title wrap stockists-intro"><div class="eyebrow"><?php echo esc_html(megas_t('ΠΟΥ ΘΑ ΤΟΝ ΒΡΕΙΣ','WHERE TO FIND IT')); ?></div><h1><?php echo megas_lines(megas_t("Κοντά σου,\nσε κάθε γουλιά.","Close to you,\nin every sip.")); ?></h1><p><?php echo esc_html(megas_t('Ανακάλυψε τα σημεία πώλησης του Μέγα και δες ακριβώς ποια προϊόντα είναι διαθέσιμα σε κάθε κατάστημα.','Discover Megas stockists and see exactly which products are available at each store.')); ?></p></section>
<section class="stockists-map-section wrap" aria-label="<?php echo esc_attr(megas_t('Χάρτης σημείων πώλησης στην Ελλάδα','Stockist map of Greece')); ?>">
<?php $first_location=megas_google_shared_map_id() ? '' : megas_stockist_map_location($stores[0]); ?>
<div class="stockists-map-viewport<?php echo megas_google_shared_map_id() ? ' stockists-map-viewport--shared' : ''; ?>">
<iframe id="stockists-map" class="stockists-map stockists-google-map" src="<?php echo esc_url(megas_stockist_google_embed($first_location)); ?>" title="<?php echo esc_attr(megas_t('Google Maps — Σημεία πώλησης Μέγας','Google Maps — Megas stockists')); ?>" width="1240" height="650" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
</div>
<p class="stockists-map-caption"><?php echo esc_html(megas_google_shared_map_id() ? megas_t('Τα σημεία πώλησής μας','Our stockists') : $stores[0]['name']); ?></p>
</section>
<section class="stockists-help wrap"><p><?php echo esc_html(megas_t('Για τη διαθεσιμότητα συγκεκριμένων προϊόντων, επικοινωνήστε με το σημείο πώλησης πριν από την επίσκεψή σας.','For availability of specific products, please contact the store before visiting.')); ?></p><a class="underlink" href="<?php echo esc_url(megas_contact_url()); ?>"><?php echo esc_html(megas_t('Χρειάζεστε βοήθεια; Μιλήστε μαζί μας.','Need help? Get in touch.')); ?> <?php megas_arrow(); ?></a></section>
</main><?php get_footer(); ?>
