<?php
if (!defined('ABSPATH')) { exit; }
function megas_world_url($page='about') {
    return add_query_arg('megas_world','about',megas_home()).($page==='philosophy' ? '#philosophy' : '');
}
function megas_world_page() {
    $page=get_query_var('megas_world');
    return in_array($page,array('about','philosophy'),true) ? $page : '';
}
add_filter('query_vars',function($vars){$vars[]='megas_world';return $vars;});
add_filter('template_include',function($template){return megas_world_page() ? get_theme_file_path('template-world.php') : $template;},30);
add_filter('pre_get_document_title',function($title){
    $page=megas_world_page();
    return $page ? megas_t('Σχετικά με εμάς','About us').' — Μέγας' : $title;
},30);
/* Collapse old World/About/Philosophy entries in assigned menus without editing stored menus. */
add_filter('wp_nav_menu_objects',function($items,$args){
    if(!in_array($args->theme_location ?? '',array('primary','footer_company'),true)){return $items;}
    $labels=array('Ο κόσμος μας','Our world','Σχετικά με εμάς','About us','Η φιλοσοφία μας','Our philosophy');
    $matches=array();
    foreach($items as $item){
        if(!(int)$item->menu_item_parent && in_array(trim(wp_strip_all_tags($item->title)),$labels,true)){$matches[]=(int)$item->ID;}
    }
    if(!$matches){return $items;}
    $keep=$matches[0];$removed=array_slice($matches,1);$parents=$matches;
    do {
        $added=false;
        foreach($items as $item){
            if(in_array((int)$item->menu_item_parent,$parents,true) && !in_array((int)$item->ID,$removed,true)){
                $removed[]=(int)$item->ID;$parents[]=(int)$item->ID;$added=true;
            }
        }
    } while($added);
    $result=array();
    foreach($items as $item){
        if(in_array((int)$item->ID,$removed,true)){continue;}
        if((int)$item->ID===$keep){
            $item=clone $item;$item->title=megas_t('Σχετικά με εμάς','About us');$item->url=megas_world_url('about');
            $item->classes=array_values(array_diff((array)$item->classes,array('menu-item-has-children','current-menu-parent','current-menu-ancestor')));
            $item->current=(bool)megas_world_page();$item->current_item_parent=false;$item->current_item_ancestor=false;
        }
        $result[]=$item;
    }
    return $result;
},20,2);

function megas_about_photos() {
    $defaults=array(
        1=>array('file'=>'assets/images/about/panagiotis-vogiovits.jpg','width'=>4248,'height'=>5929,'alt'=>megas_t('Παναγιώτης Βόγιοβιτς δίπλα στη μηχανή καβουρδίσματος','Panagiotis Vogiovits beside the coffee roaster')),
        2=>array('file'=>'assets/images/about/megas-wood-cup.webp','width'=>1536,'height'=>1024,'alt'=>megas_t('Κλασικός Μέγας Ελληνικός Καφές και φλιτζάνι καφέ','Megas Classic Greek Coffee and a cup of coffee')),
    );
    $photos=array();
    for($index=1;$index<=3;$index++){
        $id=absint(get_theme_mod('megas_about_photo_'.$index,0));
        if($id && wp_attachment_is_image($id)){
            $metadata=wp_get_attachment_metadata($id);
            $photos[]=array('id'=>$id,'width'=>(int)($metadata['width'] ?? 1),'height'=>(int)($metadata['height'] ?? 1));
        } elseif(isset($defaults[$index]) && is_file(get_theme_file_path($defaults[$index]['file']))) {
            $photos[]=array_merge(array('id'=>0),$defaults[$index]);
        }
    }
    return $photos;
}
