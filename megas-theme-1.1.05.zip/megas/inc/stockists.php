<?php
if (!defined('ABSPATH')) { exit; }
function megas_stockist_coordinate($value,$min,$max) {
    if(!is_scalar($value) || trim((string)$value)==='' || !is_numeric($value)){return null;}
    $value=(float)$value;
    return is_finite($value) && $value>=$min && $value<=$max ? $value : null;
}
function megas_stockist_default_entries() {
    return 'ΣΤΟΑ Αγορά | Αθήνα | Σταδίου, Αθήνα | | 37.9814375 | 23.7304375 | XPJJ+H5 Αθήνα
Pecan nuts & coffee | Κόρινθος | Ερμού, Κόρινθος |  | 37.9374375 | 22.9321875 | WWPJ+XV Κόρινθος
Σταματόπουλος Μάρκετ | Κόρινθος | Κόρινθος |  | 37.9301875 | 22.9280625 | WWJH+36 Κόρινθος
Μάρκετ Βάβαρη | Λέχαιο Κορινθίας | Λέχαιο Κορινθίας |  | 37.9358125 | 22.8424375 | WRPR+8X Λέχαιο
Μάρκετ Τα Πάντα Όλα | Λουτράκι Κορινθίας | Λουτράκι Κορινθίας |  | 37.9691875 | 22.9779375 | XX9H+M5 Λουτράκι
Μάρκετ Τα Πάντα Όλα | Λουτρά Ωραίας Ελένης Κορινθίας | Λουτρά Ωραίας Ελένης Κορινθίας |  | 37.8620625 | 22.9968125 | VX6W+RP Λουτρά Ωραίας Ελένης
Μάρκετ Γκούβα | Εξαμίλια Κορινθίας | Εξαμίλια Κορινθίας |  | 37.8971875 | 22.9270625 | VWWG+VR Εξαμίλια
Ψιλικά Πιτσούνης | Ζευγολατιό Κορινθίας | Ζευγολατιό Κορινθίας |  | 37.9391875 | 22.8005625 | WRQ2+M6 Ζευγολατειό
Μάρκετ Μαυραντζάς | Μελίσσι Κορινθίας | Μελίσσι Κορινθίας |  | 38.0475625 | 22.6841875 | 2MXM+2M Μελίσσι
Politirio Concept Store | Αρχαία Κόρινθος | Αρχαία Κόρινθος |  | 37.9068125 | 22.8798125 | WV4H+PW Αρχαία Κόρινθος
Αχυρώνας | Ξυλόκαστρο | Ξυλόκαστρο Κορινθίας |  | 38.0785625 | 22.6294375 | 3JHH+CQ Ξυλόκαστρο
Καφενείο Παραδοσιακό | Ξυλόκαστρο Κορινθίας | Παναγή Τσαλδάρη 32, Ξυλόκαστρο Κορινθίας |  | 38.0788125 | 22.6323125 | 3JHJ+GW Ξυλόκαστρο
Φούρνος Πλασσαρά | Λέχαιο Κορινθίας | Λέχαιο Κορινθίας |  | 37.9355625 | 22.8441875 | WRPV+6M Λέχαιο
Βελλινιάτη — Ταβέρνα Παντοπωλείο | Λαλιώτης Κορινθίας | Λαλιώτης Κορινθίας |  | 38.0120625 | 22.6765625 | 2M6G+RJ Λαλιώτης
Καφέ Παντοπωλείο Μπεκιάρης | Γκούρα Κορινθίας | Γκούρα Κορινθίας |  | 37.9336875 | 22.3411875 | W8MR+FF Γκούρα';
}
function megas_stockists() {
    $stores=array(array(
        'name'=>megas_t('Μέγας Ελληνικός Καφές — Earth Supplies Ε.Ε.','Megas Greek Coffee — Earth Supplies E.E.'),
        'city'=>megas_t('Κόρινθος','Corinth'),
        'address'=>megas_contact_value('address'),
        'phone'=>megas_contact_value('phone'),
        'hours'=>megas_contact_value(megas_en() ? 'en_hours' : 'hours'),
        'location'=>get_theme_mod('megas_store_plus_code','WWRH+QQ Κόρινθος'),
        'latitude'=>megas_stockist_coordinate(get_theme_mod('megas_store_latitude','37.9419375'),-90,90),
        'longitude'=>megas_stockist_coordinate(get_theme_mod('megas_store_longitude','22.9294375'),-180,180),
    ));
    $entries=get_theme_mod('megas_stockist_entries',megas_stockist_default_entries());
    foreach(preg_split('/\r\n|\r|\n/', $entries) as $line){
        if(trim($line)===''){continue;}
        $fields=array_map('trim',explode('|',$line));
        if(count($fields)<3 || !$fields[0] || !$fields[1] || !$fields[2]){continue;}
        $stores[]=array('name'=>$fields[0],'city'=>$fields[1],'address'=>$fields[2],'phone'=>$fields[3] ?? '','hours'=>'','location'=>$fields[6] ?? '','latitude'=>megas_stockist_coordinate($fields[4] ?? '',-90,90),'longitude'=>megas_stockist_coordinate($fields[5] ?? '',-180,180));
    }
    return $stores;
}
add_filter('query_vars',function($vars){$vars[]='megas_stockists';return $vars;});
add_filter('template_include',function($template){return get_query_var('megas_stockists')==='1' ? get_theme_file_path('template-stockists.php') : $template;},30);
add_filter('pre_get_document_title',function($title){return (get_query_var('megas_stockists')==='1' || is_page_template('template-stockists.php')) ? megas_t('Πού θα τον βρεις','Where to find it').' — Μέγας' : $title;},30);
add_action('customize_register',function($customizer){
    $customizer->add_section('megas_stockists',array('title'=>'Σημεία πώλησης','panel'=>'megas'));
    $customizer->add_setting('megas_google_mymaps_url',array('default'=>megas_google_mymaps_default_url(),'sanitize_callback'=>'esc_url_raw'));
    $customizer->add_control('megas_google_mymaps_url',array('label'=>'Σύνδεσμος κοινού χάρτη Google My Maps','description'=>'Εισάγετε το αρχείο KML στο Google My Maps, επιλέξτε κανονικό υπόβαθρο χάρτη και επικολλήστε εδώ τον δημόσιο σύνδεσμο.','section'=>'megas_stockists','type'=>'url'));
    $customizer->add_setting('megas_store_plus_code',array('default'=>'WWRH+QQ Κόρινθος','sanitize_callback'=>'sanitize_text_field'));
    $customizer->add_control('megas_store_plus_code',array('label'=>'Plus Code καταστήματος Κορίνθου (με πόλη)','section'=>'megas_stockists','type'=>'text'));
    foreach(array('latitude'=>'Γεωγραφικό πλάτος καταστήματος Κορίνθου','longitude'=>'Γεωγραφικό μήκος καταστήματος Κορίνθου') as $key=>$label){
        $customizer->add_setting('megas_store_'.$key,array('default'=>'','sanitize_callback'=>'sanitize_text_field'));
        $customizer->add_control('megas_store_'.$key,array('label'=>$label,'section'=>'megas_stockists','type'=>'text'));
    }
    $customizer->add_setting('megas_stockist_entries',array('default'=>megas_stockist_default_entries(),'sanitize_callback'=>'sanitize_textarea_field'));
    $customizer->add_control('megas_stockist_entries',array('label'=>'Επιπλέον σημεία πώλησης','description'=>'Ένα κατάστημα ανά γραμμή: Όνομα | Πόλη | Πλήρης διεύθυνση | Τηλέφωνο (προαιρετικό) | Γεωγραφικό πλάτος | Γεωγραφικό μήκος | Plus Code με πόλη (εναλλακτικά). Για τα pin χρειάζονται οι ακριβείς συντεταγμένες. Το κατάστημα της Κορίνθου εμφανίζεται αυτόματα από τα στοιχεία επικοινωνίας.','section'=>'megas_stockists','type'=>'textarea'));
});

add_action('wp_enqueue_scripts',function(){
    if(get_query_var('megas_stockists')!=='1' && !is_page_template('template-stockists.php')){return;}
    $version=wp_get_theme()->get('Version');
    wp_enqueue_script('megas-stockists-map',get_theme_file_uri('assets/js/stockists-map.js'),array(),$version,true);
});

function megas_stockist_map_location($store) {
    if(!empty($store['location'])){return $store['location'];}
    if ($store['latitude'] !== null && $store['longitude'] !== null) { return $store['latitude'].','.$store['longitude']; }
    return $store['location'] ?? '';
}
function megas_google_mymaps_default_url() { return 'https://www.google.com/maps/d/edit?mid=1kR6lAEIWdVMWhc4fMyglOyuDA41j3Hw&usp=sharing'; }
function megas_google_shared_map_id() {
    $url=get_theme_mod('megas_google_mymaps_url',megas_google_mymaps_default_url());
    if(!$url){$url=megas_google_mymaps_default_url();}
    if(!$url || !in_array(wp_parse_url($url,PHP_URL_HOST),array('google.com','www.google.com','maps.google.com'),true)){return '';}
    parse_str(wp_parse_url($url,PHP_URL_QUERY) ?: '',$query);
    return isset($query['mid']) && is_string($query['mid']) && preg_match('/^[A-Za-z0-9_-]{10,}$/',$query['mid']) ? $query['mid'] : '';
}
function megas_stockist_google_embed($location) {
    $shared_id=megas_google_shared_map_id();
    if($shared_id){
        $params=array('mid'=>$shared_id,'hl'=>megas_en() ? 'en' : 'el','ehbc'=>'2E312F','noprof'=>'1','ll'=>'38.4,24','z'=>'6');
        foreach(megas_stockists() as $store){
            if($location && megas_stockist_map_location($store)===$location && $store['latitude']!==null && $store['longitude']!==null){
                $params['ll']=$store['latitude'].','.$store['longitude'];$params['z']='13';break;
            }
        }
        return add_query_arg($params,'https://www.google.com/maps/d/embed');
    }

    return add_query_arg(array('q'=>rawurlencode($location),'hl'=>megas_en() ? 'en' : 'el','t'=>'m','z'=>'6','output'=>'embed'),'https://maps.google.com/maps');
}
