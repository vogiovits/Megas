<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="product-grid">
<?php $files=array('classic-200g.webp','classic-500g.webp','beans-4kg.webp','cup.webp');foreach($files as $i=>$file): ?>
<article class="product-card <?php echo $i===3?'cup-product':''; ?>"><a href="<?php echo esc_url(megas_product_url($i)); ?>"><div class="product-photo"><img src="<?php echo esc_url(megas_image('products/'.$file,'megas_image_product_'.$i)); ?>" width="1121" height="1403" alt="<?php echo esc_attr(megas_text('product_'.$i)); ?>" loading="<?php echo get_query_var('megas_products')==='1' || is_page_template('template-products.php') ? 'eager' : 'lazy'; ?>" decoding="async"></div><div class="product-heading"><p class="product-label"><?php echo esc_html(megas_text('product_'.$i)); ?></p><span aria-hidden="true"><?php megas_arrow(); ?></span></div></a></article>
<?php endforeach; ?></div>
