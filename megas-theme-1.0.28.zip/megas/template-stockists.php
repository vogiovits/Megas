<?php
/* Template Name: Μέγας — Πού θα μας βρείτε */
if (!defined('ABSPATH')) { exit; }
$stores=megas_stockists();
get_header();
?>
<main id="main-content" class="stockists-page">
<section class="page-title wrap"><div class="eyebrow"><?php echo esc_html(megas_t('ΣΗΜΕΙΑ ΠΩΛΗΣΗΣ','STOCKISTS')); ?></div><h1><?php echo esc_html(megas_t('Πού θα μας βρείτε','Where to find us')); ?></h1><p><?php echo esc_html(megas_t('Γνωρίστε από κοντά τον Μέγα Ελληνικό Καφέ. Βρείτε τα σημεία πώλησης και επιλέξτε αυτό που σας εξυπηρετεί.','Discover Megas Greek Coffee in person. Find a stockist and choose the location that suits you.')); ?></p></section>
<section class="stockists-map-section wrap" aria-label="<?php echo esc_attr(megas_t('Χάρτης σημείων πώλησης στην Ελλάδα','Stockist map of Greece')); ?>">
<?php $first_location=megas_google_shared_map_id() ? '' : megas_stockist_map_location($stores[0]); ?>
<iframe id="stockists-map" class="stockists-map stockists-google-map" src="<?php echo esc_url(megas_stockist_google_embed($first_location)); ?>" title="<?php echo esc_attr(megas_t('Google Maps — Σημεία πώλησης Μέγας','Google Maps — Megas stockists')); ?>" width="1240" height="650" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
<p class="stockists-map-caption"><?php echo esc_html(megas_google_shared_map_id() ? megas_t('Τα σημεία πώλησής μας','Our stockists') : $stores[0]['name']); ?></p>
</section>
<section class="stockists-list wrap" aria-label="<?php echo esc_attr(megas_t('Καταστήματα','Stores')); ?>">
<?php foreach($stores as $store_index=>$store): ?>
<article class="stockist-card" id="stockist-<?php echo (int)$store_index; ?>"><div class="eyebrow"><?php echo esc_html($store['city']); ?></div><h2><?php echo esc_html($store['name']); ?></h2><address><?php echo esc_html($store['address']); ?></address>
<?php if($store['phone']): ?><p class="stockist-phone"><span><?php echo esc_html(megas_t('Τηλέφωνο','Telephone')); ?> </span><a href="tel:<?php echo esc_attr(preg_replace('/[^+0-9]/','',$store['phone'])); ?>"><?php echo esc_html($store['phone']); ?></a></p><?php endif; ?>
<?php if($store['hours']): ?><p class="stockist-hours"><?php echo nl2br(esc_html($store['hours'])); ?></p><?php endif; ?>
<?php $map_location=megas_stockist_map_location($store); if($map_location): ?><button type="button" class="stockist-show-map underlink" data-map-url="<?php echo esc_url(megas_stockist_google_embed($map_location)); ?>" data-map-name="<?php echo esc_attr($store['name']); ?>"><?php echo esc_html(megas_t('Δείτε στον χάρτη','Show on map')); ?></button><?php endif; ?>
<?php if($store['address']): ?><a class="underlink" href="<?php echo esc_url(add_query_arg(array('api'=>'1','destination'=>rawurlencode($map_location ?: $store['name'].', '.$store['address'])),'https://www.google.com/maps/dir/')); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(megas_t('Οδηγίες διαδρομής','Get directions')); ?> <?php megas_arrow(); ?></a><?php endif; ?>
</article><?php endforeach; ?>
</section>
<section class="stockists-help wrap"><p><?php echo esc_html(megas_t('Για τη διαθεσιμότητα συγκεκριμένων προϊόντων, επικοινωνήστε με το σημείο πώλησης πριν από την επίσκεψή σας.','For availability of specific products, please contact the store before visiting.')); ?></p><a class="underlink" href="<?php echo esc_url(megas_contact_url()); ?>"><?php echo esc_html(megas_t('Χρειάζεστε βοήθεια; Μιλήστε μαζί μας.','Need help? Get in touch.')); ?> <?php megas_arrow(); ?></a></section>
</main><?php get_footer(); ?>
