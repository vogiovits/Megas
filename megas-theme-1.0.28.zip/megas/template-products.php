<?php
/* Template Name: Μέγας — Τα προϊόντα μας */
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main id="main-content" class="products-page"><section class="page-title wrap"><div class="eyebrow"><?php echo esc_html(megas_t('Η ΣΕΙΡΑ ΜΑΣ','OUR COLLECTION')); ?></div><h1><?php echo esc_html(megas_t('Τα προϊόντα μας','Our products')); ?></h1></section>
<section class="wrap home-products products-catalogue" aria-label="<?php echo esc_attr(megas_t('Προϊόντα Μέγας','Megas products')); ?>"><?php get_template_part('template-parts/product-grid'); ?></section>
</main><?php get_footer(); ?>
