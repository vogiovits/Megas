<?php
/* Template Name: Μέγας — Συχνές ερωτήσεις */
get_header();
$faqs=array(
 array(megas_t('Ποιες συσκευασίες διαθέτει ο Μέγας;','Which pack sizes are available?'),esc_html(megas_t('Κλασικός Αλεσμένος 200g και 500g, Κλασικός σε Κόκκους 4kg για επαγγελματική χρήση.','Classic Ground 200g and 500g, and Classic Whole Bean 4kg for professional use.'))),
 array(megas_t('Ο καφές 4kg είναι αλεσμένος;','Is the 4kg coffee ground?'),esc_html(megas_t('Ο καφές στη συσκευασία των 4 κιλών είναι σε κόκκους και απαιτείται μύλος για να αλεστεί.','The coffee in the 4kg pack comes as whole beans and requires a coffee grinder.'))),
 array(megas_t('Πώς μπορώ να συνεργαστώ μαζί σας;','How can I become a partner?'),esc_html(megas_t('Στείλε μας ένα μήνυμα με τα στοιχεία της επιχείρησής σου και θα συζητήσουμε τις ανάγκες σου.','Send us your business details and we will discuss your needs.'))),
 array(megas_t('Πού μπορώ να βρω τα προϊόντα σας;','Where can I find your products?'),esc_html(megas_t('Μπορείτε να δείτε κάποια από τα σημεία πώλησης των προϊόντων μας ','You can find some of the locations that stock our products ')).'<a href="'.esc_url(megas_stockists_url()).'"><strong>'.esc_html(megas_t('εδώ','here')).'</strong></a>.'),
 array(megas_t('Μπορώ να αγοράσω online;','Can I buy online?'),esc_html(megas_t('Η ιστοσελίδα παρουσιάζει τα προϊόντα μας. Υπάρχει η δυνατότητα να αγοράσετε τα προϊόντα μας με ανακατεύθυνση στο ηλεκτρονικό μας κατάστημα ','This website presents our products. You can purchase them by visiting our online shop at ')).'<a href="'.esc_url('https://www.earthcoffeeco.shop/').'">www.earthcoffeeco.shop</a>')
);
?>
<main id="main-content"><section class="page-title wrap"><div class="eyebrow">FAQ</div><h1><?php echo esc_html(megas_t('Συχνές ερωτήσεις','Frequently asked questions')); ?></h1></section><section class="wrap faq-content"><?php foreach($faqs as $i=>$item): ?><details class="faq-item" <?php echo $i===0?'open':''; ?>><summary><?php echo esc_html($item[0]); ?></summary><p><?php echo wp_kses($item[1],array('a'=>array('href'=>array()),'strong'=>array())); ?></p></details><?php endforeach; ?></section></main><?php get_footer(); ?>
