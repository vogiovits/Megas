Map geometry: Natural Earth 1:50m admin-0 countries, v5.1.2. Public domain.
Source: https://github.com/nvkelso/natural-earth-vector/tree/v5.1.2
Selected countries around Greece; properties reduced to country names.
