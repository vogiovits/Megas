(()=>{
 const map=document.getElementById('stockists-map');
 if(!map)return;
 document.querySelectorAll('.stockist-show-map').forEach(button=>button.addEventListener('click',()=>{
  const url=new URL(button.dataset.mapUrl);
  if(url.protocol!=='https:'||!['maps.google.com','www.google.com'].includes(url.hostname))return;
  if(map.src!==url.href)map.src=url.href;
  document.querySelector('.stockists-map-caption').textContent=button.dataset.mapName;
  map.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth',block:'center'});
 }));
})();
