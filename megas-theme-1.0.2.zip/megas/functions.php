<?php
/** Megas theme bootstrap. */
if (!defined('ABSPATH')) { exit; }
require_once get_template_directory() . '/inc/settings.php';
require_once get_template_directory() . '/inc/contact.php';
function megas_setup() {
    load_theme_textdomain('megas', get_template_directory() . '/languages');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array('height'=>500,'width'=>500,'flex-height'=>true,'flex-width'=>true));
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
    add_theme_support('responsive-embeds');
    register_nav_menus(array('primary'=>'Κύριο μενού','footer_company'=>'Footer — Η εταιρεία','footer_business'=>'Footer — Επαγγελματίες','footer_help'=>'Footer — Χρήσιμα'));
}
add_action('after_setup_theme', 'megas_setup');
function megas_assets() {
    $version = wp_get_theme()->get('Version');
    wp_enqueue_style('megas-site',get_theme_file_uri('assets/css/site.css'),array(),$version);
    wp_enqueue_script('megas-site',get_theme_file_uri('assets/js/site.js'),array(),$version,true);
}
add_action('wp_enqueue_scripts','megas_assets');
function megas_en() {
    if(function_exists('pll_current_language'))return pll_current_language('slug')==='en';
    $language=isset($_GET['megas_lang']) && is_string($_GET['megas_lang']) ? wp_unslash($_GET['megas_lang']) : '';
    if(in_array($language,array('el','en'),true))return $language==='en';
    return get_theme_mod('megas_language','el')==='en';
}
function megas_t($el,$en) { return megas_en() ? $en : $el; }
function megas_asset($file) { return get_theme_file_uri('assets/images/' . $file); }
function megas_image($file,$setting='') { $custom=$setting ? get_theme_mod($setting,'') : ''; return $custom ?: megas_asset($file); }
function megas_text($key) { $defaults=megas_defaults(); $prefix=megas_en()?'en_':''; return get_theme_mod('megas_'.$prefix.$key,$defaults[$prefix.$key] ?? $defaults[$key] ?? ''); }
function megas_lines($text) { return nl2br(esc_html($text)); }
function megas_accent_lines($text) { $parts=explode("\n",$text,2);return esc_html($parts[0]).(isset($parts[1])?'<br><em>'.megas_lines($parts[1]).'</em>':''); }
/** An explicit landing route keeps the logo on the designed homepage, including translated homes. */
function megas_home($language='') {
    $base=home_url('/');
    if(function_exists('pll_home_url')) {
        $translated=$language ? pll_home_url($language) : pll_home_url();
        if(is_string($translated) && $translated!=='')$base=$translated;
    } else {
        $language=$language ?: (megas_en()?'en':'el');
        if($language==='en')$base=get_theme_mod('megas_english_url','') ?: $base;
        $base=add_query_arg('megas_lang',$language,$base);
    }
    return add_query_arg('megas_home','1',$base);
}
function megas_is_home_request() {
    return get_query_var('megas_home')==='1' && !get_query_var('megas_contact') && !get_query_var('megas_faq');
}
function megas_contact_url() {
    $custom=get_theme_mod('megas_contact_url',''); if ($custom) { return $custom; }
    $pages=get_pages(array('meta_key'=>'_wp_page_template','meta_value'=>'template-contact.php','number'=>1));
    return $pages ? get_permalink($pages[0]) : add_query_arg('megas_contact','1',megas_home());
}
function megas_faq_url() { $page=get_page_by_path('faq'); return $page ? get_permalink($page) : add_query_arg('megas_faq','1',megas_home()); }
function megas_product_url($index) {
    $custom=get_theme_mod('megas_product_url_'.$index,'');
    return $custom ?: add_query_arg('product',(string)$index,megas_contact_url());
}
function megas_brand() {
    $id=get_theme_mod('custom_logo');
    $url=$id ? wp_get_attachment_image_url($id,'full') : megas_asset('brand/megas-logo.png');
    echo '<a class="brand" href="'.esc_url(megas_home()).'" aria-label="'.esc_attr(megas_t('Μέγας — Αρχική','Megas — Home')).'"><img class="brand-logo" src="'.esc_url($url).'" alt="Μέγας Ελληνικός Καφές" width="500" height="500"></a>';
}
function megas_arrow() { echo '<span class="arrow" aria-hidden="true">↗</span>'; }
function megas_fallback_menu() {
    echo '<ul class="menu"><li class="menu-item-has-children"><a href="'.esc_url(megas_home().'#about').'">'.esc_html(megas_t('Ο κόσμος μας','Our world')).'</a><ul class="sub-menu"><li><a href="'.esc_url(megas_home().'#about').'">'.esc_html(megas_t('Η φιλοσοφία μας','Our philosophy')).'</a></li><li><a href="'.esc_url(megas_home().'#preparation').'">'.esc_html(megas_t('Η τέχνη του ελληνικού','The coffee ritual')).'</a></li></ul></li>';
    foreach (array('products'=>megas_t('Τα προϊόντα μας','Our products'),'professionals'=>megas_t('Επαγγελματίες','Professionals')) as $id=>$label) { echo '<li><a href="'.esc_url(megas_home().'#'.$id).'">'.esc_html($label).'</a></li>'; }
    echo '<li><a href="'.esc_url(megas_contact_url()).'">'.esc_html(megas_t('Επικοινωνία','Contact')).'</a></li></ul>';
}
add_filter('query_vars',function($vars){ $vars[]='megas_contact';$vars[]='megas_faq';$vars[]='megas_home';$vars[]='megas_lang';return $vars; });
add_filter('template_include',function($template){if(get_query_var('megas_contact'))return get_theme_file_path('template-contact.php');if(get_query_var('megas_faq'))return get_theme_file_path('template-faq.php');if(megas_is_home_request())return get_theme_file_path('front-page.php');return $template;});
add_filter('pre_get_document_title',function($title){if(get_query_var('megas_contact'))return megas_t('Επικοινωνία','Contact').' — Μέγας';if(get_query_var('megas_faq'))return 'FAQ — Μέγας';if(megas_is_home_request())return get_bloginfo('name');return $title;});

// Keep WordPress canonical redirects from removing the explicit homepage route.
add_filter('redirect_canonical',function($redirect){return megas_is_home_request()?false:$redirect;});
add_filter('pre_handle_404',function($handled,$query){
    if(megas_is_home_request()){$query->is_404=false;status_header(200);return true;}
    return $handled;
},10,2);
